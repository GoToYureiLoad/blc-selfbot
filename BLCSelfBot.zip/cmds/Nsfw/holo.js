const discord = require('discord.js');
const superagent = require('superagent')

module.exports.run = (bot, message, args) => {
  if (message.channel.nsfw === true) {
    superagent.get('https://nekobot.xyz/api/image')
    .query({ type: 'holo'})
    .end((err, response) => {
      const asskembed = new discord.RichEmbed()
        .setTitle("Olo hentai image 🔞")
        .setColor('#000000')
        .setImage(response.body.message);
      message.edit(asskembed)
    });
  } else {
    superagent.get('https://nekobot.xyz/api/image')
    .query({ type: 'holo'})
    .end((err, response) => {
      const asskembed = new discord.RichEmbed()
        .setTitle("Olo hentai image 🔞")
        .setColor('#000000')
        .setImage(response.body.message);
      message.edit(asskembed)
    });
  }
};

module.exports.help = {
    name: "holo"
}